/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package racecar;

import java.awt.Rectangle;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.animation.Animation;
import javafx.animation.PathTransition; 
import javafx.application.Application;
 import javafx.scene.Scene;
 import javafx.scene.image.ImageView;
 import javafx.scene.layout.Pane;
 import javafx.scene.shape.Line;
 import javafx.stage.Stage;
 import javafx.util.Duration;
import javafx.scene.shape.Polygon; 
import javafx.application.Application; 
import javafx.scene.Group; 
import javafx.scene.Scene; 
import javafx.scene.shape.Polygon; 
import javafx.stage.Stage;  

public class RaceCar extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Polygon polygon = new Polygon();
        //Adding coordinates to the polygon 
      polygon.getPoints().addAll(new Double[]{ 
         300.0, 50.0, 
         450.0, 150.0, 
         300.0, 250.0, 
         150.0, 150.0, 
      });  
        //Adding coordinates to the polygon 
      polygon.getPoints().addAll(new Double[]{ 
         300.0, 50.0, 
         450.0, 150.0, 
         300.0, 250.0, 
         150.0, 150.0, 
      }); 
          
      //Creating a Group object  
      Group root = new Group(polygon); 
         
        
        Rectangle rectangle = new Rectangle (0, 0, 25, 50);
        Pane pane = new Pane();
        ImageView imageView = new ImageView("/ferrari.jpg");
        pane.getChildren().add(imageView);

        PathTransition pt = new PathTransition(Duration.millis(10000),
        
        new Line(100, 200, 100, 0), imageView);
        pt.setCycleCount(5);
        pt.play(); // Start animation
 
        Scene scene = new Scene(pane, 300, 250);
        
        primaryStage.setTitle("Car Racer");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    
}
